<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;
use App\Models\Feedback;

class Query extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'query',
        'response',
    ];

    /**
     * Get the user that owns the query.
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the feedback for the query.
     */
    public function feedback()
    {
        return $this->hasOne(Feedback::class);
    }
}
