<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Query;

class Feedback extends Model
{
    use HasFactory;

    protected $fillable = [
        'query_id',
        'is_helpful',
        'comments',
    ];

    /**
     * Get the query that owns the feedback.
     */
    public function feedbackQuery()
    {
        return $this->belongsTo(Query::class);
    }
}
