<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommunityManager extends Model
{
    use HasFactory;

    protected $fillable = ['user_id', 'message', 'response'];

    // You can also set up relationships here if you need to link users, etc.
}
