<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Feedback;
use App\Services\GaiaNetService;

class ProcessFeedback extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'feedback:process';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Process user feedback and improve AI responses';

    protected $gaiaNet;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(GaiaNetService $gaiaNet)
    {
        parent::__construct();
        $this->gaiaNet = $gaiaNet;
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // Fetch all negative feedback that hasn't been processed yet
        $feedbacks = Feedback::where('is_helpful', false)->whereNull('processed_at')->get();

        foreach ($feedbacks as $feedback) {
            // Notify GaiaNet for improvement
            $this->gaiaNet->notifyForImprovement($feedback->query_id);

            // Mark feedback as processed
            $feedback->update(['processed_at' => now()]);
        }

        $this->info('Feedback processed successfully.');
        return 0;
    }
}
