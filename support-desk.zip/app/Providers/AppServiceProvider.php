<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use App\Services\GaiaNetService;
use App\Services\OpenAIService;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->singleton(GaiaNetService::class, function ($app) {
            return new GaiaNetService();
        });

        $this->app->singleton(OpenAIService::class, function ($app) {
            return new OpenAIService();
        });
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
