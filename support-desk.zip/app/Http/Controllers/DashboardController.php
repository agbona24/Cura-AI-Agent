<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Query;

class DashboardController extends Controller
{
    public function index()
    {
        $queries = Query::where('user_id', auth()->user()->id)->orderBy('created_at', 'desc')->get();
        return view('dashboard', compact('queries'));
    }
}
