<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reward;
use App\Models\Transaction;
use Illuminate\Support\Facades\Auth;

class CreditsController extends Controller
{
    /**
     * Display the Credits & Rewards Dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function dashboard()
    {
        $user = Auth::user();
        $rewards = Reward::all();
        $transactions = Transaction::where('user_id', $user->id)->orderBy('created_at', 'desc')->get();

        return view('credits.dashboard', compact('rewards', 'transactions'));
    }

    /**
     * Redeem a reward.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function redeem(Request $request)
    {
        $request->validate([
            'reward_id' => 'required|exists:rewards,id',
        ]);

        $user = Auth::user();
        $reward = Reward::findOrFail($request->reward_id);

        if ($user->credits < $reward->cost) {
            return response()->json(['message' => 'Insufficient credits to redeem this reward.'], 400);
        }

        // Deduct credits
        $user->spendCredits($reward->cost);

        // Create transaction
        Transaction::create([
            'user_id' => $user->id,
            'reward_id' => $reward->id,
            'type' => 'spend',
            'amount' => $reward->cost,
        ]);

        return response()->json(['message' => 'Reward redeemed successfully!'], 200);
    }
}
