<?php

namespace App\Http\Controllers;

use App\Models\Query;
use App\Models\Feedback;
use App\Models\Transaction;
use Illuminate\Http\Request;
use App\Services\OpenAIService;
use App\Services\GaiaNetService;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;

class SupportDeskController extends Controller
{
    protected $gaiaNet;
    protected $openAI;

    public function __construct(GaiaNetService $gaiaNet, OpenAIService $openAI)
    {
        $this->gaiaNet = $gaiaNet;
        $this->openAI = $openAI;
    }

    /**
     * Handle participant queries.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function handleQuery(Request $request)
    {
        Log::info('handleQuery called');
    
        $request->validate([
            'query' => 'required|string|max:1000',
        ]);
    
        Log::info('Request validated', ['query' => $request->query]);
    
        // Get the authenticated user
        $user = Auth::user();
    
        if (!$user) {
            Log::warning('Unauthenticated access to handleQuery');
            return response()->json(['message' => 'Unauthenticated'], 401);
        }
    
        Log::info('Authenticated user', ['user_id' => $user->id]);
    
        // Log the query
        $query = Query::create([
            'user_id' => $user->id,
            'query' => $request->query,
        ]);
    
        Log::info('Query logged', ['query_id' => $query->id]);
    
        // Generate AI response with contextual understanding
        $aiResponse = $this->openAI->generateContextualResponse($user->id, $request->query);
    
        Log::info('AI response generated', ['response' => $aiResponse]);
    
        // Save the response
        $query->update(['response' => $aiResponse]);
    
        // Award 5 credits for submitting a query
        $user->earnCredits(5);
        Transaction::create([
            'user_id' => $user->id,
            'reward_id' => null, // No reward associated
            'type' => 'earn',
            'amount' => 5,
        ]);
    
        Log::info('Credits awarded to user', ['user_id' => $user->id, 'amount' => 5]);
    
        // Optionally, submit learned data to GaiaNet
        $this->gaiaNet->submitLearnedData('Support Query', $aiResponse);
        Log::info('Learned data submitted to GaiaNet');
    
        return response()->json([
            'query_id' => $query->id,
            'response' => $aiResponse,
        ], 200);
    }
    


    /**
     * Retrieve query history for a user.
     *
     * @param int $user_id
     * @return \Illuminate\Http\JsonResponse
     */
    public function getHistory($user_id)
    {
        $queries = Query::where('user_id', $user_id)->orderBy('created_at', 'desc')->get();
        return response()->json(['history' => $queries], 200);
    }

    /**
     * Submit feedback on AI response.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function submitFeedback(Request $request)
{
    $request->validate([
        'query_id' => 'required|exists:queries,id',
        'is_helpful' => 'required|boolean',
        'comments' => 'nullable|string|max:500',
    ]);

    // Get the authenticated user
    $user = Auth::user();

    // Ensure the query belongs to the user
    $query = Query::where('id', $request->query_id)
                  ->where('user_id', $user->id)
                  ->firstOrFail();

    // Create feedback entry
    Feedback::create([
        'query_id' => $query->id,
        'is_helpful' => $request->is_helpful,
        'comments' => $request->comments,
    ]);

    // Award credits based on feedback
    if ($request->is_helpful) {
        // Award 2 credits for helpful feedback
        $user->earnCredits(2);
        Transaction::create([
            'user_id' => $user->id,
            'reward_id' => null,
            'type' => 'earn',
            'amount' => 2,
        ]);
    }

    // Trigger learning process if feedback is negative
    if (!$request->is_helpful) {
        $this->gaiaNet->notifyForImprovement($query->id);
    }

    return response()->json(['message' => 'Feedback submitted successfully'], 200);
}

}
