<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Query;
use App\Models\Content;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommunityController extends Controller
{
    /**
     * Display the Community Dashboard.
     *
     * @return \Illuminate\View\View
     */
    public function dashboard()
    {
        // Fetch user-generated content
        $contents = Content::with('user')
            ->where('is_flagged', true)
            ->latest()
            ->paginate(10); // Paginate for better performance

        // Fetch community events
        $events = Event::latest()->paginate(5);

        // Fetch engagement data (placeholder data)
        $engagementLabels = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $engagementData = [15, 25, 20, 30, 10, 5, 12]; // Replace with real data

        return view('community.dashboard', compact('contents', 'events', 'engagementLabels', 'engagementData'));
    }

    /**
     * Approve the flagged content.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function approveContent($id)
    {
        $content = Content::findOrFail($id);
    $content->is_flagged = false;
    $content->is_approved = true;
    $content->save();

    // Award 10 credits for approving content
    $user = Auth::user(); // Assuming the moderator is the authenticated user
    $user->earnCredits(10);
    Transaction::create([
        'user_id' => $user->id,
        'reward_id' => null,
        'type' => 'earn',
        'amount' => 10,
    ]);

    return response()->json(['message' => 'Content approved successfully'], 200);
    }

    /**
     * Reject the flagged content.
     *
     * @param int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function rejectContent($id)
    {
        $content = Content::findOrFail($id);
    $content->is_flagged = false;
    $content->is_rejected = true;
    $content->save();

    // Award 5 credits for rejecting content
    $user = Auth::user(); // Assuming the moderator is the authenticated user
    $user->earnCredits(5);
    Transaction::create([
        'user_id' => $user->id,
        'reward_id' => null,
        'type' => 'earn',
        'amount' => 5,
    ]);

    return response()->json(['message' => 'Content rejected successfully'], 200);
    }

    public function recommendContent($user_id)
{
    // Fetch user's recent activities or interests
    // For simplicity, use recent queries

    $recent_queries = Query::where('user_id', $user_id)
        ->latest()
        ->take(5)
        ->pluck('query')
        ->toArray();

    $current_query = 'Suggest community content based on the following interests: ' . implode(', ', $recent_queries);

    $aiResponse = $this->openAI->generateContextualResponse($user_id, $current_query);

    return response()->json(['recommendations' => $aiResponse], 200);
}

public function suggestModerationActions($content_id)
{
    $content = Content::findOrFail($content_id);

    $current_query = 'Analyze the following content and suggest moderation actions: ' . $content->content;

    $aiResponse = $this->openAI->generateContextualResponse($content->user_id, $current_query);

    return response()->json(['suggestions' => $aiResponse], 200);
}


}
