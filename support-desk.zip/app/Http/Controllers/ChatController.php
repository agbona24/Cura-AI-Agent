<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ChatMessage;
use Illuminate\Support\Facades\Auth;
use App\Events\NewChatMessage;

class ChatController extends Controller
{
    /**
     * Display the chat interface.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        $messages = ChatMessage::with('user')->latest()->take(50)->get()->reverse();
        return view('community.chat', compact('messages'));
    }

    /**
     * Send a new chat message.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function sendMessage(Request $request)
    {
        $request->validate([
            'message' => 'required|string|max:1000',
        ]);

        $message = ChatMessage::create([
            'user_id' => Auth::id(),
            'message' => $request->message,
        ]);

        // Broadcast the new message
        broadcast(new NewChatMessage($message->load('user')))->toOthers();

        return response()->json(['message' => 'Message sent successfully'], 200);
    }
}
