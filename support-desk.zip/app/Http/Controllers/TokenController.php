<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class TokenController extends Controller
{
    /**
     * Generate an API token for a user.
     *
     * @param Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function generateToken(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
        ]);

        $user = User::find($request->user_id);
        $token = $user->createToken('API Token')->plainTextToken;

        return response()->json([
            'message' => 'Token generated successfully.',
            'token' => $token,
        ]);
    }
}
