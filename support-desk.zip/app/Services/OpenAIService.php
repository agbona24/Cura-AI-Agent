<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use App\Models\Query;
use Illuminate\Support\Facades\Log;

class OpenAIService
{
    protected $baseUrl;
    protected $apiKey;
    protected $useGaiaNet;
    protected $aiModel;

    public function __construct()
    {
        // Determine whether to use GaiaNet or OpenAI based on configuration
        $this->useGaiaNet = config('services.gaianet.use', false);

        if ($this->useGaiaNet) {
            $this->baseUrl = rtrim(config('services.gaianet.base_url'), '/');
            $this->apiKey = config('services.gaianet.api_key', '');
            $this->aiModel = config('services.gaianet.ai_model', 'Meta-Llama-3-8B-Instruct-Q5_K_M');
        } else {
            $this->baseUrl = rtrim(config('services.openai.base_url', 'https://api.openai.com/v1'), '/');
            $this->apiKey = config('services.openai.api_key');
            $this->aiModel = config('services.openai.ai_model', 'gpt-3.5-turbo');
        }
    }

    /**
     * Generate AI response with contextual understanding.
     *
     * @param int $user_id
     * @param string $current_query
     * @return string
     */
    public function generateContextualResponse($user_id, $current_query)
    {
        Log::info('Generating AI response', ['user_id' => $user_id, 'query' => $current_query]);

        // Retrieve last few queries and responses for context
        $previous_conversations = Query::where('user_id', $user_id)
            ->latest()
            ->take(5)
            ->get()
            ->reverse()
            ->map(function($q) {
                return [
                    ['role' => 'user', 'content' => $q->query],
                    ['role' => 'assistant', 'content' => $q->response],
                ];
            })
            ->flatten(1)
            ->toArray();

        // Append the current user query
        $messages = array_merge([
            ['role' => 'system', 'content' => 'You are a helpful assistant.'],
        ], $previous_conversations, [
            ['role' => 'user', 'content' => $current_query],
        ]);

        // Define the endpoint based on the service
        $endpoint = "{$this->baseUrl}/chat/completions";

        Log::info('Sending request to AI endpoint', ['endpoint' => $endpoint]);

        try {
            $response = Http::retry(3, 100) // Retry 3 times with 100ms delay
                ->withHeaders([
                    'Authorization' => !empty($this->apiKey) ? 'Bearer ' . $this->apiKey : '',
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                ])
                ->post($endpoint, [
                    'model' => $this->aiModel,
                    'messages' => $messages,
                    'temperature' => 0.7,
                    'max_tokens' => 500,
                    'top_p' => 1,
                    'frequency_penalty' => 0,
                    'presence_penalty' => 0,
                ]);

            Log::info('Received response from AI endpoint', ['status' => $response->status()]);

            if ($response->successful()) {
                $content = trim($response->json()['choices'][0]['message']['content']);
                Log::info('AI response content', ['content' => $content]);
                return $content;
            } elseif ($response->status() == 429) { // Too Many Requests
                Log::warning('AI API rate limit exceeded.');
                return "I'm experiencing high demand at the moment. Please try again later.";
            } else {
                Log::error('AI API Error', ['status' => $response->status(), 'response' => $response->body()]);
                return "I'm sorry, I couldn't process your request at the moment.";
            }
        } catch (\Exception $e) {
            Log::error('AI API Exception', ['message' => $e->getMessage()]);
            return "I'm sorry, I couldn't process your request at the moment.";
        }
    }

    // Additional methods can be added here for other AI endpoints if needed
}
