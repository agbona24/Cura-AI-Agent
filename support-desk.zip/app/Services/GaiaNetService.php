<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use App\Models\Query;
use App\Models\LearnedData;
use Illuminate\Support\Facades\Log;

class GaiaNetService
{
    protected $baseUrl;
    protected $apiKey;

    public function __construct()
    {
        $this->baseUrl = rtrim(env('GAIANET_API_BASE'), '/');
        $this->apiKey = env('GAIANET_API_KEY', '');
    }

    // Notify GaiaNet for improvements based on feedback
    public function notifyForImprovement($query_id)
    {
        $query = Query::find($query_id);
        $data = [
            'user_id' => $query->user_id,
            'query' => $query->query,
            'response' => $query->response,
            'feedback' => 'negative',
        ];

        // Send notification to GaiaNet API
        $response = Http::withHeaders([
            'Authorization' => !empty($this->apiKey) ? 'Bearer ' . $this->apiKey : '',
            'Accept' => 'application/json',
        ])->post("{$this->baseUrl}/agent/support-desk/improve", $data);

        if($response->successful()){
            Log::info('GaiaNet Improvement Submission Successful', ['query_id' => $query_id, 'response' => $response->json()]);
        } else {
            Log::error('GaiaNet Improvement Submission Failed', ['query_id' => $query_id, 'response' => $response->body()]);
        }

        return $response->json();
    }

    // Submit Learned Data to GaiaNet
    public function submitLearnedData($topic, $content)
    {
        $data = [
            'topic' => $topic,
            'content' => $content,
        ];

        $response = Http::withHeaders([
            'Authorization' => !empty($this->apiKey) ? 'Bearer ' . $this->apiKey : '',
            'Accept' => 'application/json',
        ])->post("{$this->baseUrl}/agent/support-desk/learned-data", $data);

        if($response->successful()){
            Log::info('GaiaNet Learned Data Submission Successful', ['topic' => $topic, 'response' => $response->json()]);
        } else {
            Log::error('GaiaNet Learned Data Submission Failed', ['topic' => $topic, 'response' => $response->body()]);
        }

        return $response->json();
    }

    // Fetch Challenge Details (if needed)
    public function fetchChallengeDetails($challenge_id)
    {
        $response = Http::withHeaders([
            'Authorization' => !empty($this->apiKey) ? 'Bearer ' . $this->apiKey : '',
            'Accept' => 'application/json',
        ])->get("{$this->baseUrl}/challenges/{$challenge_id}");

        if($response->successful()){
            Log::info('GaiaNet Challenge Details Fetch Successful', ['challenge_id' => $challenge_id, 'response' => $response->json()]);
        } else {
            Log::error('GaiaNet Challenge Details Fetch Failed', ['challenge_id' => $challenge_id, 'response' => $response->body()]);
        }

        return $response->json();
    }

    // Additional GaiaNet API integrations can be added here
}
