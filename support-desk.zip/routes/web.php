<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\TokenController;
use App\Http\Controllers\CreditsController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CommunityController;
use App\Http\Controllers\DashboardController;

Route::get('/', function () {
    return view('welcome');
});

/* Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard'); */
Route::post('/generate-token', [TokenController::class, 'generateToken']);

Route::middleware(['auth'])->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/support', function(){
        return view('support.chat');
    })->name('support.chat');

    //PROFILE CONTROLLER
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    //COMMUNITY CONTROLLER
    Route::get('/community/dashboard', [CommunityController::class, 'dashboard'])->name('community.dashboard');

    //CREDIT CONTROLLER
    Route::get('/credits/dashboard', [CreditsController::class, 'dashboard'])->name('credits.dashboard');
    Route::post('/credits/redeem', [CreditsController::class, 'redeem'])->name('credits.redeem');

     // Moderation routes
     Route::post('/community/content/{id}/approve', [CommunityController::class, 'approveContent'])->name('community.content.approve');
     Route::post('/community/content/{id}/reject', [CommunityController::class, 'rejectContent'])->name('community.content.reject');

      // Chat Routes
    Route::get('/community/chat', [ChatController::class, 'index'])->name('community.chat');
    Route::post('/community/chat/send', [ChatController::class, 'sendMessage'])->name('community.chat.send');

      // AI Content Recommendations
      Route::get('/community/recommendations', [CommunityController::class, 'recommendContent'])->name('community.recommendations');

       // AI Moderation Suggestions
    Route::get('/community/moderation/suggestions/{content_id}', [CommunityController::class, 'suggestModerationActions'])->name('community.moderation.suggestions');
});

Route::get('/test-ai', function () {
    $aiService = app()->make(App\Services\OpenAIService::class);
    $response = $aiService->generateContextualResponse(Auth::id(), 'What is the capital of France?');
    return response()->json(['response' => $response]);
});




require __DIR__.'/auth.php';
