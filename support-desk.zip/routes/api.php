<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CreditsController;
use App\Http\Controllers\CommunityController;
use App\Http\Controllers\SupportDeskController;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::get('/test', function () {
    return response()->json(['message' => 'API is working!']);
});

// Authentication Routes
Route::post('/login', [AuthController::class, 'login']);

// Protected Routes
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/support/query', [SupportDeskController::class, 'handleQuery'])->name('support.query');
    Route::post('/support/feedback', [SupportDeskController::class, 'submitFeedback'])->name('support.feedback');
    Route::get('/support/history/{user}', [SupportDeskController::class, 'getHistory']);

    Route::post('/community/content/{id}/approve', [CommunityController::class, 'approveContent']);
    Route::post('/community/content/{id}/reject', [CommunityController::class, 'rejectContent']);

    //CREDIT CONTROLLER
    Route::post('/credits/redeem', [CreditsController::class, 'redeem']);
});
