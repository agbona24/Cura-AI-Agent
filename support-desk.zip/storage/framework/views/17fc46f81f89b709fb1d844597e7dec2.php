<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Community Dashboard</h2>

    <div class="row">
        <!-- User Engagement Analytics -->
        <div class="col-md-6">
            <h4>User Engagement <i class="bi bi-bar-chart"></i></h4>
            <canvas id="userEngagementChart" width="400" height="200"></canvas>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <h4>AI-Powered Content Recommendations <i class="bi bi-lightbulb-fill"></i></h4>
                <div id="recommendations">
                    <p>Loading recommendations...</p>
                </div>
            </div>
        </div>
        <!-- Content Moderation Tools -->
        <div class="col-md-6">

            <!-- Inside the content moderation list-group-item -->
<button class="btn btn-sm btn-info" onclick="fetchModerationSuggestions(<?php echo e($content->id); ?>)">
    <i class="bi bi-lightbulb-fill"></i> Suggest Actions
</button>
<div id="suggestions-<?php echo e($content->id); ?>" class="mt-2"></div>

            <h4>Content Moderation <i class="bi bi-exclamation-triangle"></i></h4>
            <div class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="list-group-item">
                        <p><strong>User:</strong> <?php echo e($content->user->name); ?></p>
                        <p><?php echo e($content->content); ?></p>
                        <button class="btn btn-sm btn-success me-2" onclick="approveContent(<?php echo e($content->id); ?>)">
                            <i class="bi bi-check-circle"></i> Approve
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="rejectContent(<?php echo e($content->id); ?>)">
                            <i class="bi bi-x-circle"></i> Reject
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No flagged content at the moment.</p>
                <?php endif; ?>
            </div>

            <!-- Pagination Links -->
            <div class="mt-3">
                <?php echo e($contents->links()); ?>

            </div>
        </div>
    </div>

    <!-- Community Events -->
    <div class="row mt-4">
        <div class="col-md-12">
            <h4>Community Events <i class="bi bi-calendar-event"></i></h4>
            <ul class="list-group">
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="list-group-item">
                        <strong><?php echo e($event->title); ?></strong> - <?php echo e(\Carbon\Carbon::parse($event->date)->format('F j, Y g:i A')); ?>

                        <p><?php echo e($event->description); ?></p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No upcoming events.</p>
                <?php endif; ?>
            </ul>


            <!-- Pagination Links -->
            <div class="mt-3">
                <?php echo e($events->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Include Chart.js and Bootstrap Icons -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<script>
    // User Engagement Chart
    const ctx = document.getElementById('userEngagementChart').getContext('2d');
    const userEngagementChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($engagementLabels); ?>,
            datasets: [{
                label: '# of Active Users',
                data: <?php echo json_encode($engagementData); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.4)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                fill: true,
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
            },
        }
    });

    // Approve Content Function
    async function approveContent(content_id) {
        if(!confirm('Are you sure you want to approve this content?')) return;

        const response = await fetch(`/community/content/${content_id}/approve`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Authorization': 'Bearer <?php echo e(auth()->user()->tokens()->first()->plainTextToken ?? ''); ?>'
            }
        });

        if(response.ok){
            location.reload();
        } else {
            alert("Failed to approve content.");
        }
    }

    // Reject Content Function
    async function rejectContent(content_id) {
        if(!confirm('Are you sure you want to reject this content?')) return;

        const response = await fetch(`/community/content/${content_id}/reject`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                'Authorization': 'Bearer <?php echo e(auth()->user()->tokens()->first()->plainTextToken ?? ''); ?>'
            }
        });

        if(response.ok){
            location.reload();
        } else {
            alert("Failed to reject content.");
        }
    }
</script>
<script>
    async function fetchModerationSuggestions(content_id) {
        const suggestionsDiv = document.getElementById(`suggestions-${content_id}`);
        suggestionsDiv.innerHTML = 'Loading suggestions...';

        const response = await fetch(`/community/moderation/suggestions/${content_id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            }
        });

        if(response.ok){
            const data = await response.json();
            suggestionsDiv.innerHTML = `<p>${data.suggestions}</p>`;
        } else {
            suggestionsDiv.innerHTML = `<p>Failed to load suggestions.</p>`;
        }
    }
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        fetchRecommendations();
    });

    async function fetchRecommendations() {
        const response = await fetch('<?php echo e(route('community.recommendations', Auth::id())); ?>', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            }
        });

        if(response.ok){
            const data = await response.json();
            document.getElementById('recommendations').innerHTML = `<p>${data.recommendations}</p>`;
        } else {
            document.getElementById('recommendations').innerHTML = `<p>Failed to load recommendations.</p>`;
        }
    }
</script>

<?php $__env->stopSection(); ?>

<style>
    .card-header i {
        margin-left: 5px;
    }
    .list-group-item p {
        margin-bottom: 0.5rem;
    }
</style>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\support-desk\resources\views\community\dashboard.blade.php ENDPATH**/ ?>