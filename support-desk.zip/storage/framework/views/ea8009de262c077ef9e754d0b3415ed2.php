<?php $__env->startSection('content'); ?>
<div class="chat-container">
    <h3>Support Desk AI Agent</h3>
    <div class="chat-box" id="chatBox">
        <!-- Messages will be appended here -->
    </div>
    <form id="chatForm" class="mt-3">
        <div class="input-group">
            <input type="text" class="form-control" id="userQuery" placeholder="Type your question..." required>
            <button class="btn btn-primary" type="submit">Send</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.getElementById('chatForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const userQuery = document.getElementById('userQuery').value.trim();
        if(userQuery === '') return;

        appendMessage('User', userQuery);
        document.getElementById('userQuery').value = '';

        // Append typing indicator
        const typingIndicator = appendMessage('AI', "Typing...");
        const typingDiv = typingIndicator.querySelector('.ai-message');
        typingDiv.id = 'typingIndicator';

        // Send query to backend
        const response = await fetch('/api/support/query', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer <?php echo e(auth()->user()->tokens()->first()->plainTextToken ?? ''); ?>'
            },
            body: JSON.stringify({
                query: userQuery
            })
        });

        if(response.ok){
            const data = await response.json();
            if(data.response){
                // Remove typing indicator
                const typingElement = document.getElementById('typingIndicator');
                typingElement.remove();

                appendMessage('AI', data.response);
                // Add feedback buttons
                addFeedbackButtons(data.query_id);
            }
        } else {
            // Remove typing indicator
            const typingElement = document.getElementById('typingIndicator');
            typingElement.remove();

            appendMessage('AI', "I'm sorry, I couldn't process your request at the moment.");
        }
    });

    function appendMessage(sender, message) {
        const chatBox = document.getElementById('chatBox');
        const messageDiv = document.createElement('div');
        messageDiv.classList.add(sender === 'User' ? 'user-message' : 'ai-message');
        messageDiv.innerHTML = `<strong>${sender}:</strong> ${message}`;
        chatBox.appendChild(messageDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
        return messageDiv;
    }

    function addFeedbackButtons(query_id) {
        const chatBox = document.getElementById('chatBox');
        const feedbackDiv = document.createElement('div');
        feedbackDiv.classList.add('feedback-buttons', 'ai-message');
        feedbackDiv.innerHTML = `
            <button class="btn btn-sm btn-success me-2" onclick="submitFeedback(${query_id}, true)">👍 Helpful</button>
            <button class="btn btn-sm btn-danger" onclick="submitFeedback(${query_id}, false)">👎 Not Helpful</button>
        `;
        chatBox.appendChild(feedbackDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    async function submitFeedback(query_id, is_helpful) {
        const comments = prompt("Please provide additional comments (optional):");
        const response = await fetch('/api/support/feedback', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer <?php echo e(auth()->user()->tokens()->first()->plainTextToken ?? ''); ?>'
            },
            body: JSON.stringify({
                query_id: query_id,
                is_helpful: is_helpful,
                comments: comments
            })
        });

        if(response.ok){
            const data = await response.json();
            if(data.message){
                alert(data.message);
                // Optionally, remove feedback buttons after submission
                const feedbackButtons = document.querySelectorAll(`[onclick="submitFeedback(${query_id}, true)"]`)[0].parentElement;
                feedbackButtons.remove();
            }
        } else {
            const error = await response.json();
            alert(error.message || "Failed to submit feedback.");
        }
    }
</script>
<style>
    .chat-container {
        max-width: 800px;
        margin: auto;
        padding: 20px;
    }
    .chat-box {
        border: 1px solid #ddd;
        border-radius: 5px;
        padding: 10px;
        height: 400px;
        overflow-y: scroll;
        background-color: #f9f9f9;
    }
    .user-message {
        text-align: right;
        margin: 10px 0;
    }
    .ai-message {
        text-align: left;
        margin: 10px 0;
    }
    .feedback-buttons button {
        margin-right: 5px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\support-desk\resources\views\support\chat.blade.php ENDPATH**/ ?>