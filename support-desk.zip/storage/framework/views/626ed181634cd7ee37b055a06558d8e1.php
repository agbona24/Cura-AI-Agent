<!-- resources/views/user/dashboard.blade.php -->



<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Welcome, <?php echo e(auth()->user()->name); ?></h2>
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card text-white bg-success mb-3">
                <div class="card-header">Support</div>
                <div class="card-body">
                    <h5 class="card-title">Chat with Support Agent</h5>
                    <a href="<?php echo e(route('support.chat')); ?>" class="btn btn-light">Go to Support</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-warning mb-3">
                <div class="card-header">Community</div>
                <div class="card-body">
                    <h5 class="card-title">Manage Community</h5>
                    <a href="<?php echo e(route('community.dashboard')); ?>" class="btn btn-light">Go to Community Dashboard</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-white bg-info mb-3">
                <div class="card-header">Credits & Rewards</div>
                <div class="card-body">
                    <h5 class="card-title">Track and Redeem Rewards</h5>
                    <a href="<?php echo e(route('credits.dashboard')); ?>" class="btn btn-light">Go to Credits Dashboard</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\support-desk\resources\views\user\dashboard.blade.php ENDPATH**/ ?>