<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Credits & Rewards Dashboard</h2>
    <div class="row">
        <!-- Credits Overview -->
        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3">
                <div class="card-header">Your Credits</div>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e(auth()->user()->credits); ?> Credits</h5>
                    <p class="card-text">Earned through participation and contributions.</p>
                </div>
            </div>
        </div>
        <!-- Redeem Rewards -->
        <div class="col-md-8">
            <h4>Redeem Rewards <i class="bi bi-gift-fill"></i></h4>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $rewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4">
                        <div class="card mb-3">
                            <?php if($reward->image): ?>
                                <img src="<?php echo e(asset($reward->image)); ?>" class="card-img-top" alt="<?php echo e($reward->name); ?>">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($reward->name); ?></h5>
                                <p class="card-text"><?php echo e($reward->description); ?></p>
                                <p><strong>Cost:</strong> <?php echo e($reward->cost); ?> Credits</p>
                                <button class="btn btn-success" onclick="redeemReward(<?php echo e($reward->id); ?>)"><i class="bi bi-arrow-repeat"></i> Redeem</button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No rewards available at the moment.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Transaction History -->
    <div class="row mt-4">
        <div class="col-md-12">
            <h4>Transaction History <i class="bi bi-clock-history"></i></h4>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Reward</th>
                        <th>Type</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $txn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($txn->created_at->format('Y-m-d H:i')); ?></td>
                            <td><?php echo e($txn->reward->name); ?></td>
                            <td><?php echo e(ucfirst($txn->type)); ?></td>
                            <td><?php echo e($txn->amount); ?> Credits</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center">No transactions found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Include Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<script>
    async function redeemReward(reward_id) {
        const response = await fetch('/api/credits/redeem', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer <?php echo e(auth()->user()->tokens()->first()->plainTextToken ?? ''); ?>'
            },
            body: JSON.stringify({
                reward_id: reward_id
            })
        });

        if(response.ok){
            const data = await response.json();
            if(data.message){
                alert(data.message);
                location.reload();
            }
        } else {
            const error = await response.json();
            alert(error.message || "Failed to redeem reward.");
        }
    }
</script>
<style>
    .card-header i {
        margin-left: 5px;
    }
    .card-img-top {
        height: 200px;
        object-fit: cover;
    }
    .card-body .btn {
        width: 100%;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\support-desk\resources\views/credits/dashboard.blade.php ENDPATH**/ ?>