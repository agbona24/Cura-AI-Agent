

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Community Chat <i class="bi bi-chat-dots"></i></h2>
    <div id="chatBox" class="border p-3 mb-3" style="height: 400px; overflow-y: scroll;">
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-2">
                <strong><?php echo e($message->user->name); ?>:</strong> <?php echo e($message->message); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <form id="chatForm">
        <?php echo csrf_field(); ?>
        <div class="input-group">
            <input type="text" class="form-control" id="messageInput" placeholder="Type your message..." required>
            <button class="btn btn-primary" type="submit">Send</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Include Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<!-- Include Laravel Echo and Pusher -->
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script> <!-- Ensure Laravel Echo is bundled here -->

<script>
    // Initialize Echo
    window.Echo.channel('community-chat')
        .listen('.new-message', (e) => {
            appendMessage(e.chatMessage.user.name, e.chatMessage.message);
        });

    // Handle form submission
    document.getElementById('chatForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();
        if(message === '') return;

        // Append user's message
        appendMessage('You', message);
        messageInput.value = '';

        // Send message to backend
        const response = await fetch('<?php echo e(route('community.chat.send')); ?>', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
            },
            body: JSON.stringify({ message: message })
        });

        if(response.ok){
            // Optionally handle success
        } else {
            alert("Failed to send message.");
        }
    });

    function appendMessage(sender, message) {
        const chatBox = document.getElementById('chatBox');
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('mb-2');
        messageDiv.innerHTML = `<strong>${sender}:</strong> ${message}`;
        chatBox.appendChild(messageDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
</script>

<style>
    .input-group button {
        min-width: 100px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\support-desk\resources\views\community\chat.blade.php ENDPATH**/ ?>