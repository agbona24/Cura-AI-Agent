@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Community Dashboard</h2>

    <div class="row">
        <!-- User Engagement Analytics -->
        <div class="col-md-6">
            <h4>User Engagement <i class="bi bi-bar-chart"></i></h4>
            <canvas id="userEngagementChart" width="400" height="200"></canvas>
        </div>
        <div class="row mt-4">
            <div class="col-md-12">
                <h4>AI-Powered Content Recommendations <i class="bi bi-lightbulb-fill"></i></h4>
                <div id="recommendations">
                    <p>Loading recommendations...</p>
                </div>
            </div>
        </div>
        <!-- Content Moderation Tools -->
        <div class="col-md-6">

           {{--  <!-- Inside the content moderation list-group-item -->
<button class="btn btn-sm btn-info" onclick="fetchModerationSuggestions({{ $content->id }})">
    <i class="bi bi-lightbulb-fill"></i> Suggest Actions
</button>
<div id="suggestions-{{ $content->id }}" class="mt-2"></div> --}}

            <h4>Content Moderation <i class="bi bi-exclamation-triangle"></i></h4>
            <div class="list-group">
                @forelse($contents as $content)
                    <div class="list-group-item">
                        <p><strong>User:</strong> {{ $content->user->name }}</p>
                        <p>{{ $content->content }}</p>
                        <button class="btn btn-sm btn-success me-2" onclick="approveContent({{ $content->id }})">
                            <i class="bi bi-check-circle"></i> Approve
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="rejectContent({{ $content->id }})">
                            <i class="bi bi-x-circle"></i> Reject
                        </button>
                    </div>
                @empty
                    <p>No flagged content at the moment.</p>
                @endforelse
            </div>

            <!-- Pagination Links -->
            <div class="mt-3">
                {{ $contents->links() }}
            </div>
        </div>
    </div>

    <!-- Community Events -->
    <div class="row mt-4">
        <div class="col-md-12">
            <h4>Community Events <i class="bi bi-calendar-event"></i></h4>
            <ul class="list-group">
                @forelse($events as $event)
                    <li class="list-group-item">
                        <strong>{{ $event->title }}</strong> - {{ \Carbon\Carbon::parse($event->date)->format('F j, Y g:i A') }}
                        <p>{{ $event->description }}</p>
                    </li>
                @empty
                    <p>No upcoming events.</p>
                @endforelse
            </ul>


            <!-- Pagination Links -->
            <div class="mt-3">
                {{ $events->links() }}
            </div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<!-- Include Chart.js and Bootstrap Icons -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<script>
    // User Engagement Chart
    const ctx = document.getElementById('userEngagementChart').getContext('2d');
    const userEngagementChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: {!! json_encode($engagementLabels) !!},
            datasets: [{
                label: '# of Active Users',
                data: {!! json_encode($engagementData) !!},
                backgroundColor: 'rgba(54, 162, 235, 0.4)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                fill: true,
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
            },
        }
    });

    // Approve Content Function
    async function approveContent(content_id) {
        if(!confirm('Are you sure you want to approve this content?')) return;

        const response = await fetch(`/community/content/${content_id}/approve`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Authorization': 'Bearer {{ auth()->user()->tokens()->first()->plainTextToken ?? '' }}'
            }
        });

        if(response.ok){
            location.reload();
        } else {
            alert("Failed to approve content.");
        }
    }

    // Reject Content Function
    async function rejectContent(content_id) {
        if(!confirm('Are you sure you want to reject this content?')) return;

        const response = await fetch(`/community/content/${content_id}/reject`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Authorization': 'Bearer {{ auth()->user()->tokens()->first()->plainTextToken ?? '' }}'
            }
        });

        if(response.ok){
            location.reload();
        } else {
            alert("Failed to reject content.");
        }
    }
</script>
<script>
    async function fetchModerationSuggestions(content_id) {
        const suggestionsDiv = document.getElementById(`suggestions-${content_id}`);
        suggestionsDiv.innerHTML = 'Loading suggestions...';

        const response = await fetch(`/community/moderation/suggestions/${content_id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            }
        });

        if(response.ok){
            const data = await response.json();
            suggestionsDiv.innerHTML = `<p>${data.suggestions}</p>`;
        } else {
            suggestionsDiv.innerHTML = `<p>Failed to load suggestions.</p>`;
        }
    }
</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        fetchRecommendations();
    });

    async function fetchRecommendations() {
        const response = await fetch('{{ route('community.recommendations', Auth::id()) }}', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            }
        });

        if(response.ok){
            const data = await response.json();
            document.getElementById('recommendations').innerHTML = `<p>${data.recommendations}</p>`;
        } else {
            document.getElementById('recommendations').innerHTML = `<p>Failed to load recommendations.</p>`;
        }
    }
</script>

@endsection

<style>
    .card-header i {
        margin-left: 5px;
    }
    .list-group-item p {
        margin-bottom: 0.5rem;
    }
</style>
