@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Community Chat <i class="bi bi-chat-dots"></i></h2>
    <div id="chatBox" class="border p-3 mb-3" style="height: 400px; overflow-y: scroll;">
        @foreach($messages as $message)
            <div class="mb-2">
                <strong>{{ $message->user->name }}:</strong> {{ $message->message }}
            </div>
        @endforeach
    </div>
    <form id="chatForm">
        @csrf
        <div class="input-group">
            <input type="text" class="form-control" id="messageInput" placeholder="Type your message..." required>
            <button class="btn btn-primary" type="submit">Send</button>
        </div>
    </form>
</div>
@endsection

@section('scripts')
<!-- Include Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

<!-- Include Laravel Echo and Pusher -->
<script src="https://js.pusher.com/7.0/pusher.min.js"></script>
<script src="{{ asset('js/app.js') }}"></script> <!-- Ensure Laravel Echo is bundled here -->

<script>
    // Initialize Echo
    window.Echo.channel('community-chat')
        .listen('.new-message', (e) => {
            appendMessage(e.chatMessage.user.name, e.chatMessage.message);
        });

    // Handle form submission
    document.getElementById('chatForm').addEventListener('submit', async function(e) {
        e.preventDefault();
        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();
        if(message === '') return;

        // Append user's message
        appendMessage('You', message);
        messageInput.value = '';

        // Send message to backend
        const response = await fetch('{{ route('community.chat.send') }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
            },
            body: JSON.stringify({ message: message })
        });

        if(response.ok){
            // Optionally handle success
        } else {
            alert("Failed to send message.");
        }
    });

    function appendMessage(sender, message) {
        const chatBox = document.getElementById('chatBox');
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('mb-2');
        messageDiv.innerHTML = `<strong>${sender}:</strong> ${message}`;
        chatBox.appendChild(messageDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
</script>

<style>
    .input-group button {
        min-width: 100px;
    }
</style>
@endsection
