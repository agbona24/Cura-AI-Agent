@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Credits & Rewards Dashboard</h2>
    <div class="row">
        <!-- Credits Overview -->
        <div class="col-md-4">
            <div class="card text-white bg-primary mb-3">
                <div class="card-header">Your Credits</div>
                <div class="card-body">
                    <h5 class="card-title">{{ auth()->user()->credits }} Credits</h5>
                    <p class="card-text">Earned through participation and contributions.</p>
                </div>
            </div>
        </div>
        <!-- Redeem Rewards -->
        <div class="col-md-8">
            <h4>Redeem Rewards <i class="bi bi-gift-fill"></i></h4>
            <div class="row">
                @forelse($rewards as $reward)
                    <div class="col-md-4">
                        <div class="card mb-3">
                            @if($reward->image)
                                <img src="{{ asset($reward->image) }}" class="card-img-top" alt="{{ $reward->name }}">
                            @endif
                            <div class="card-body">
                                <h5 class="card-title">{{ $reward->name }}</h5>
                                <p class="card-text">{{ $reward->description }}</p>
                                <p><strong>Cost:</strong> {{ $reward->cost }} Credits</p>
                                <button class="btn btn-success" onclick="redeemReward({{ $reward->id }})"><i class="bi bi-arrow-repeat"></i> Redeem</button>
                            </div>
                        </div>
                    </div>
                @empty
                    <p>No rewards available at the moment.</p>
                @endforelse
            </div>
        </div>
    </div>

    <!-- Transaction History -->
    <div class="row mt-4">
        <div class="col-md-12">
            <h4>Transaction History <i class="bi bi-clock-history"></i></h4>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Reward</th>
                        <th>Type</th>
                        <th>Amount</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($transactions as $txn)
                        <tr>
                            <td>{{ $txn->created_at->format('Y-m-d H:i') }}</td>
                            <td>{{ $txn->reward->name }}</td>
                            <td>{{ ucfirst($txn->type) }}</td>
                            <td>{{ $txn->amount }} Credits</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="4" class="text-center">No transactions found.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<!-- Include Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
<script>
    async function redeemReward(reward_id) {
        const response = await fetch('/api/credits/redeem', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer {{ auth()->user()->tokens()->first()->plainTextToken ?? '' }}'
            },
            body: JSON.stringify({
                reward_id: reward_id
            })
        });

        if(response.ok){
            const data = await response.json();
            if(data.message){
                alert(data.message);
                location.reload();
            }
        } else {
            const error = await response.json();
            alert(error.message || "Failed to redeem reward.");
        }
    }
</script>
<style>
    .card-header i {
        margin-left: 5px;
    }
    .card-img-top {
        height: 200px;
        object-fit: cover;
    }
    .card-body .btn {
        width: 100%;
    }
</style>
@endsection
