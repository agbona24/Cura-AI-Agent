<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    {{ __("You're logged in!") }}
                </div>
            </div>

            <!-- User Dashboard Content -->
            <div class="container mt-6">
                <h2>User Dashboard</h2>
                <div class="row">
                    <div class="col-md-6">
                        <h4>Profile Information</h4>
                        <p><strong>Name:</strong> {{ auth()->user()->name }}</p>
                        <p><strong>Email:</strong> {{ auth()->user()->email }}</p>
                    </div>
                    <div class="col-md-6">
                        <h4>Query History</h4>
                        <ul class="list-group">
                            @foreach($queries as $query)
                                <li class="list-group-item">
                                    <strong>Q:</strong> {{ $query->query }}<br>
                                    <strong>A:</strong> {{ $query->response }}<br>
                                    <strong>Feedback:</strong>
                                    @if($query->feedback)
                                        {{ $query->feedback->is_helpful ? '👍 Helpful' : '👎 Not Helpful' }}
                                    @else
                                        No Feedback
                                    @endif
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
