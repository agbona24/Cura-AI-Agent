<!-- resources/views/user/dashboard.blade.php -->

@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mt-3">Welcome, {{ auth()->user()->name }}</h2>
    <p class="text-muted">Empowering you with cutting-edge AI to simplify community management, support, and rewards.</p>

    <div class="row mt-5">
        <!-- Support Desk Section -->
        <div class="col-md-4">
            <div class="card text-white bg-success mb-4 shadow">
                <div class="card-header">Support Desk</div>
                <div class="card-body">
                    <h5 class="card-title">AI-Powered 24/7 Assistance</h5>
                    <p class="card-text">Connect with our AI Support Agent to resolve queries instantly, day or night.</p>
                    <a href="{{ route('support.chat') }}" class="btn btn-light">Access Support Desk</a>
                </div>
            </div>
        </div>

        <!-- Community Manager Section -->
        <div class="col-md-4">
            <div class="card text-white bg-warning mb-4 shadow">
                <div class="card-header">Community Strategist</div>
                <div class="card-body">
                    <h5 class="card-title">Autonomous Community Management</h5>
                    <p class="card-text">Effortlessly manage members, engage with your audience, and track insights with AI.</p>
                    <a href="{{ route('community.dashboard') }}" class="btn btn-light">Visit Community Dashboard</a>
                </div>
            </div>
        </div>

        <!-- Credits & Rewards Section -->
        <div class="col-md-4">
            <div class="card text-white bg-info mb-4 shadow">
                <div class="card-header">Credits & Rewards</div>
                <div class="card-body">
                    <h5 class="card-title">Track and Redeem Points</h5>
                    <p class="card-text">Monitor earned credits and rewards. Redeem them for exclusive perks.</p>
                    <a href="{{ route('credits.dashboard') }}" class="btn btn-light">Go to Rewards</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Recommendations Section -->
    <div class="row mt-5">
        <div class="col-12">
            <div class="card border-0 shadow">
                <div class="card-header bg-primary text-white">Recommended Actions</div>
                <div class="card-body">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">💬 <strong>Explore Chat Support:</strong> Enhance customer satisfaction by leveraging the AI Support Desk for faster query resolution.</li>
                        <li class="list-group-item">📊 <strong>Optimize Community Engagement:</strong> Use the AI Community Manager to analyze member activity and grow your network strategically.</li>
                        <li class="list-group-item">🎁 <strong>Maximize Rewards:</strong> Regularly check the Credits Dashboard to unlock valuable perks for your activities.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
