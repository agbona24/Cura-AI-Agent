<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Support</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f8fa;
            margin: 0;
            padding: 0;
        }
        .navbar {
            background-color: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .navbar-brand {
            font-weight: bold;
            color: #4c6ef5;
        }
        .navbar-nav .nav-link {
            color: #4c6ef5;
            font-weight: 500;
            margin: 0 10px;
        }
        .navbar-nav .nav-link:hover {
            color: #3b5dc9;
        }
        .hero {
            text-align: center;
            padding: 100px 20px;
            background-color: white;
        }
        .hero h1 {
            font-size: 3.5rem;
            font-weight: bold;
            color: #4c6ef5;
        }
        .hero p {
            font-size: 1.3rem;
            margin: 20px 0;
            color: #555;
        }
        .btn-primary {
            background-color: #4c6ef5;
            border: none;
            padding: 12px 40px;
            border-radius: 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #3b5dc9;
        }
        .btn-outline-secondary {
            border-radius: 30px;
            border: 2px solid #4c6ef5;
            color: #4c6ef5;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        .btn-outline-secondary:hover {
            background-color: #4c6ef5;
            color: white;
        }
        .features {
            padding: 70px 0;
            background-color: #eef4ff;
        }
        .feature-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            text-align: center;
            padding: 30px;
            background-color: #fff;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
        }
        .feature-icon {
            font-size: 3.5rem;
            color: #4c6ef5;
            margin-bottom: 20px;
        }
        .how-it-works {
            padding: 70px 0;
            background-color: #ffffff;
        }
        .step {
            text-align: center;
            padding: 25px;
            border: 1px solid #eaeaea;
            border-radius: 15px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            background-color: #f9f9f9;
        }
        .step:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
        }
        footer {
            background-color: #4c6ef5;
            color: #fff;
            padding: 50px 0;
        }
        footer .footer-content {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            align-items: flex-start;
            gap: 30px;
        }
        footer h3 {
            font-size: 1.2rem;
            font-weight: bold;
            margin-bottom: 15px;
        }
        footer p, footer ul {
            color: #d1e0ff;
        }
        footer ul {
            list-style: none;
            padding: 0;
        }
        footer ul li {
            margin-bottom: 10px;
        }
        footer ul li a {
            color: #d1e0ff;
            text-decoration: none;
            transition: color 0.3s;
        }
        footer ul li a:hover {
            color: white;
        }
        footer .social-icons a {
            color: #d1e0ff;
            margin-right: 15px;
            font-size: 1.5rem;
            transition: color 0.3s;
        }
        footer .social-icons a:hover {
            color: white;
        }
        footer .newsletter input {
            width: 100%;
            padding: 10px;
            border: 1px solid #d1e0ff;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        footer .newsletter button {
            padding: 10px 20px;
            background-color: #6fb1ff;
            border: none;
            border-radius: 5px;
            color: white;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        footer .newsletter button:hover {
            background-color: #4c6ef5;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="#">AI Support</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#features">Features</a></li>
                    <li class="nav-item"><a class="nav-link" href="#how-it-works">How it Works</a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('login') }}">Login</a></li>
                    <li class="nav-item"><a class="btn btn-primary" href="{{ route('register') }}">Register</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <header class="hero">
        <div class="container">
            <h1>Welcome to the Future of Community Support</h1>
            <p>Our AI-powered agents never sleep. They support, manage, and reward you 24/7.</p>
            <div>
                <a href="#features" class="btn btn-primary me-3">Join the Revolution Today</a>
                <a href="#" class="btn btn-outline-secondary">Learn More</a>
            </div>
        </div>
    </header>

    <!-- Features Section -->
    <section id="features" class="features">
        <div class="container">
            <h2 class="text-center mb-5">Why Choose Us?</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="bi bi-robot"></i>
                        </div>
                        <h5>AI Support Desk</h5>
                        <p>24/7 intelligent assistance for all your needs.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="bi bi-people"></i>
                        </div>
                        <h5>Community Manager</h5>
                        <p>Automated moderation and engagement.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-card">
                        <div class="feature-icon">
                            <i class="bi bi-trophy"></i>
                        </div>
                        <h5>Reward System</h5>
                        <p>Earn credits for your contributions.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section id="how-it-works" class="how-it-works">
        <div class="container">
            <h2 class="text-center mb-5">How It Works</h2>
            <div class="row g-4">
                <div class="col-md-3 step">
                    <h3 class="text-primary">01</h3>
                    <h5>Join the Community</h5>
                    <p>Create your account and become part of our growing community.</p>
                </div>
                <div class="col-md-3 step">
                    <h3 class="text-primary">02</h3>
                    <h5>Get Instant Support</h5>
                    <p>Access our AI support desk for immediate assistance 24/7.</p>
                </div>
                <div class="col-md-3 step">
                    <h3 class="text-primary">03</h3>
                    <h5>Engage & Contribute</h5>
                    <p>Participate in discussions and help other community members.</p>
                </div>
                <div class="col-md-3 step">
                    <h3 class="text-primary">04</h3>
                    <h5>Earn Rewards</h5>
                    <p>Get automatically rewarded for your valuable contributions.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container footer-content">
            <div>
                <h3>About</h3>
                <p>Revolutionizing support systems through AI and automation. <br/  >Empowering users with seamless experiences.</p>
            </div>
            <div>
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#how-it-works">How it Works</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
            <div>
                <h3>Newsletter</h3>
                <div class="newsletter">
                    <input type="email" placeholder="Your email address">
                    <button>Subscribe</button>
                </div>
            </div>
            <div>
                <h3>Follow Us</h3>
                <div class="social-icons">
                    <a href="#" target="_blank"><i class="bi bi-facebook"></i></a>
                    <a href="#" target="_blank"><i class="bi bi-twitter"></i></a>
                    <a href="#" target="_blank"><i class="bi bi-instagram"></i></a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
</body>
</html>
