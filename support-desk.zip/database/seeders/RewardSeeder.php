<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Reward;

class RewardSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Predefined rewards
        $rewards = [
            [
                'name' => 'Premium Support',
                'description' => 'Access to premium support services.',
                'cost' => 50,
                'image' => null,
            ],
            [
                'name' => 'Exclusive Webinar',
                'description' => 'Invitation to an exclusive webinar.',
                'cost' => 30,
                'image' => null,
            ],
            [
                'name' => 'E-Book',
                'description' => 'Free e-book download.',
                'cost' => 20,
                'image' => null,
            ],
            [
                'name' => 'Merchandise Discount',
                'description' => '10% discount on merchandise.',
                'cost' => 40,
                'image' => null,
            ],
            [
                'name' => 'Event Access',
                'description' => 'Free access to a community event.',
                'cost' => 25,
                'image' => null,
            ],
        ];

        foreach ($rewards as $reward) {
            Reward::create($reward);
        }
    }
}
