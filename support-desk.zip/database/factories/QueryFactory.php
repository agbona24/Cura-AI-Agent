<?php

namespace Database\Factories;

use App\Models\Query;
use Illuminate\Database\Eloquent\Factories\Factory;

class QueryFactory extends Factory
{
    protected $model = Query::class;

    public function definition()
    {
        return [
            'user_id' => 1, // Replace with dynamic data if necessary
            'query' => $this->faker->sentence,
            'response' => $this->faker->sentence,
        ];
    }
}
