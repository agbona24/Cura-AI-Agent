<?php

namespace Tests\Unit;

use PHPUnit\Framework\Attributes\Test;
use Tests\TestCase;
use App\Services\OpenAIService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Models\User;
use App\Models\Query;
use Illuminate\Support\Facades\Http;

class OpenAIServiceTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        // Set configuration to use GaiaNet
        config(['services.gaianet.use' => true]);
        config(['services.gaianet.base_url' => 'https://0x36158c9ee789ec231af6f0c0a9f0f81153b76ea9.us.gaianet.network/v1']);
        config(['services.gaianet.api_key' => 'gaia']);
        config(['services.gaianet.ai_model' => 'Meta-Llama-3-8B-Instruct-Q5_K_M']);
    }

    /** @test */
    #[Test]
    public function it_generates_ai_response_using_gaianet()
    {
        // Mock the HTTP response from GaiaNet's chat/completions endpoint
        Http::fake([
            'https://0x36158c9ee789ec231af6f0c0a9f0f81153b76ea9.us.gaianet.network/v1/chat/completions' => Http::response([
                'choices' => [
                    [
                        'message' => [
                            'role' => 'assistant',
                            'content' => '42 is the purpose of life.'
                        ]
                    ],
                ],
            ], 200),
        ]);

        $service = new OpenAIService();

        $user = User::factory()->create();
        Query::factory()->create([
            'user_id' => $user->id,
            'query' => 'What is the purpose of life?',
            'response' => '',
        ]);

        $response = $service->generateContextualResponse($user->id, 'What is the purpose of life?');

        $this->assertEquals('42 is the purpose of life.', $response);
    }
}
